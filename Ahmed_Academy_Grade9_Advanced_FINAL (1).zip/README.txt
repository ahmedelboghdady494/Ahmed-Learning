Ahmed Academy — Grade 9 Advanced Mathematics

Contents:
- index.html
- files/ with the lesson Practice, Solutions, and Explanation PDFs supplied for Modules 2–5 (available lessons)

Quiz changes:
- 10 quiz sets per lesson instead of 60.
- 10 questions per quiz.
- Questions are written in Grade 9 Advanced textbook style and aligned to the lesson topics from the supplied book/source.

Important:
This is a static GitHub Pages site. Student activity/progress is stored in the browser localStorage on that device.
